<?php

$servername = "localhost";
$username = "sirat";
$password = "000999";
$dbname = "i-broker";

// Creating connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Checking connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $crm_id = $_POST["crm_id"];
    $crm_name = $_POST["crm_name"];

    $photo1_name = $_FILES["photo"]["name"];
    $photo1_tmp = $_FILES["photo"]["tmp_name"];
    $photo1_path = "uploads/" . $photo1_name;
    move_uploaded_file($photo1_tmp, $photo1_path);

    $sql = "INSERT INTO  head_of_settlement_t VALUES('$crm_id', '$crm_name', '$photo1_path')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Data updated successfully!";
        
    } else {
        echo "Error updating data: " . $conn->error;
    }
}

$conn->close();
?>
