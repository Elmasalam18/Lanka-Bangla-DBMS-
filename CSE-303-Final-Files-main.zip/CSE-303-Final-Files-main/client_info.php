<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "i-broker";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM client_t";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch the data and store it in a PHP array
    $clients = array();
    while ($row = $result->fetch_assoc()) {
        $clients[] = $row;
    }
}

echo "<table>";
echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th></tr>";

foreach ($clients as $client) {
    echo "<tr>";
    echo "<td>" . $client['c_nid'] . "</td>";
    echo "<td>" . $client['c_name'] . "</td>";
    echo "<td>" . $client['c_email'] . "</td>";
    echo "<td>" . $client['c_present_address'] . "</td>";
    echo "</tr>";
}

echo "</table>";

$conn->close();


?>